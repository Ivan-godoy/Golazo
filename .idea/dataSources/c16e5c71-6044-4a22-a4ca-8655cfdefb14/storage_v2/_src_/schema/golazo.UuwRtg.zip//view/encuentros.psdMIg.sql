create view encuentros as
  select
    `golazo`.`fixture`.`id_temporada` AS `id_temporada`,
    `equipo_local`.`nom_equipo`       AS `nombre_equipo_local`,
    `equipo_visitante`.`nom_equipo`   AS `nombre_equipo_visita`,
    `golazo`.`fixture`.`fecha`        AS `fecha`,
    `golazo`.`fixture`.`id_fixture`   AS `id_fixture`
  from ((`golazo`.`fixture`
    join `golazo`.`equipo` `equipo_local` on ((`golazo`.`fixture`.`equipo_local` = `equipo_local`.`id_equipo`))) join
    `golazo`.`equipo` `equipo_visitante` on ((`golazo`.`fixture`.`equipo_visitante` = `equipo_visitante`.`id_equipo`)))
  order by `golazo`.`fixture`.`fecha`;

