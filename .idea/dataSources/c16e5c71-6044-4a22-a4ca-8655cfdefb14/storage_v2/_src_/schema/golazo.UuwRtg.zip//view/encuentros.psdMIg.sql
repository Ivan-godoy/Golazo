create view encuentros as
  select
    `equipo_local`.`nom_equipo`     AS `nombre_equipo_local`,
    `equipo_visitante`.`nom_equipo` AS `nombre_equipo_visita`
  from ((`golazo`.`fixture`
    join `golazo`.`equipo` `equipo_local` on ((`golazo`.`fixture`.`equipo_local` = `equipo_local`.`id_equipo`))) join
    `golazo`.`equipo` `equipo_visitante` on ((`golazo`.`fixture`.`equipo_visitante` = `equipo_visitante`.`id_equipo`)));

