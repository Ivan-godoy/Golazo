create view mostrar_resultados as
  select
    `resultados`.`id_partido_jugado` AS `id_partido_jugado`,
    `equipo_local`.`nom_equipo`      AS `equipo_local`,
    `equipo_visita`.`nom_equipo`     AS `equipo_visita`,
    `resultados`.`goles_local`       AS `goles_local`,
    `resultados`.`goles_visitante`   AS `goles_visitante`
  from ((`golazo`.`resultados`
    join `golazo`.`equipo` `equipo_local` on ((`equipo_local`.`id_equipo` = `resultados`.`equipo_local`))) join
    `golazo`.`equipo` `equipo_visita` on ((`equipo_visita`.`id_equipo` = `resultados`.`equipo_visita`)))
  order by `resultados`.`id_partido_jugado`;

