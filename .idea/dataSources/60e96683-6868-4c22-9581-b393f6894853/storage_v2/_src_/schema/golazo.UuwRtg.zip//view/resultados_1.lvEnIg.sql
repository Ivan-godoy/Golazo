create view resultados_1 as
  select
    `fix`.`id_partido_jugado`                                            AS `id_partido_jugado`,
    `fix`.`equipo_local`                                                 AS `equipo_local`,
    (select count(0)
     from `golazo`.`goles`
     where ((`fix`.`id_partido_jugado` = `fix`.`id_partido_jugado`) and
            (`golazo`.`goles`.`id_equipos_fk` = `fix`.`equipo_local`)))  AS `resultado_local`,
    `fix`.`equipo_visita`                                                AS `equipo_visita`,
    (select count(0)
     from `golazo`.`goles`
     where ((`fix`.`id_partido_jugado` = `fix`.`id_partido_jugado`) and
            (`golazo`.`goles`.`id_equipos_fk` = `fix`.`equipo_visita`))) AS `resultado_visita`
  from `golazo`.`partido_jugado` `fix`;

