create view tabla_posiciones as
  select distinct
    `golazo`.`equipo`.`nom_equipo`                                           AS `nombre_equipo`,
    ((select count(0)
      from `golazo`.`resultados`
      where ((`resultados`.`equipo_local` = `golazo`.`equipo`.`id_equipo`) and (`resultados`.`puntos_del_local` = 3))) +
     (select count(0)
      from `golazo`.`resultados`
      where ((`resultados`.`equipo_visita` = `golazo`.`equipo`.`id_equipo`) and
             (`resultados`.`puntos_del_visitante` = 3))))                    AS `PG`,
    ((select count(0)
      from `golazo`.`resultados`
      where ((`resultados`.`equipo_local` = `golazo`.`equipo`.`id_equipo`) and (`resultados`.`puntos_del_local` = 1))) +
     (select count(0)
      from `golazo`.`resultados`
      where ((`resultados`.`equipo_visita` = `golazo`.`equipo`.`id_equipo`) and
             (`resultados`.`puntos_del_visitante` = 1))))                    AS `PE`,
    ((select count(0)
      from `golazo`.`resultados`
      where ((`resultados`.`equipo_local` = `golazo`.`equipo`.`id_equipo`) and (`resultados`.`puntos_del_local` = 0))) +
     (select count(0)
      from `golazo`.`resultados`
      where ((`resultados`.`equipo_visita` = `golazo`.`equipo`.`id_equipo`) and
             (`resultados`.`puntos_del_visitante` = 0))))                    AS `PP`,
    (select count(0)
     from `golazo`.`resultados`
     where ((`resultados`.`equipo_local` = `golazo`.`equipo`.`id_equipo`) or
            (`resultados`.`equipo_visita` = `golazo`.`equipo`.`id_equipo`))) AS `PJ`,
    ((select coalesce(sum(`resultados`.`goles_local`), 0)
      from `golazo`.`resultados`
      where (`resultados`.`equipo_local` = `golazo`.`equipo`.`id_equipo`)) +
     (select coalesce(sum(`resultados`.`goles_visitante`), 0)
      from `golazo`.`resultados`
      where (`resultados`.`equipo_visita` = `golazo`.`equipo`.`id_equipo`))) AS `GF`,
    ((select coalesce(sum(`resultados`.`goles_visitante`), 0)
      from `golazo`.`resultados`
      where (`resultados`.`equipo_local` = `golazo`.`equipo`.`id_equipo`)) +
     (select coalesce(sum(`resultados`.`goles_local`), 0)
      from `golazo`.`resultados`
      where (`resultados`.`equipo_visita` = `golazo`.`equipo`.`id_equipo`))) AS `GC`,
    ((select coalesce(sum(`resultados`.`puntos_del_local`), 0)
      from `golazo`.`resultados`
      where (`resultados`.`equipo_local` = `golazo`.`equipo`.`id_equipo`)) +
     (select coalesce(sum(`resultados`.`puntos_del_visitante`), 0)
      from `golazo`.`resultados`
      where (`resultados`.`equipo_visita` = `golazo`.`equipo`.`id_equipo`))) AS `PTS`
  from (`golazo`.`equipo`
    join `golazo`.`resultados` on (((`golazo`.`equipo`.`id_equipo` = `resultados`.`equipo_local`) or
                                    (`golazo`.`equipo`.`id_equipo` = `resultados`.`equipo_visita`))))
  order by ((select coalesce(sum(`resultados`.`puntos_del_local`), 0)
             from `golazo`.`resultados`
             where (`resultados`.`equipo_local` = `golazo`.`equipo`.`id_equipo`)) +
            (select coalesce(sum(`resultados`.`puntos_del_visitante`), 0)
             from `golazo`.`resultados`
             where (`resultados`.`equipo_visita` = `golazo`.`equipo`.`id_equipo`))) desc,
    ((select coalesce(sum(`resultados`.`goles_local`), 0)
      from `golazo`.`resultados`
      where (`resultados`.`equipo_local` = `golazo`.`equipo`.`id_equipo`)) +
     (select coalesce(sum(`resultados`.`goles_visitante`), 0)
      from `golazo`.`resultados`
      where (`resultados`.`equipo_visita` = `golazo`.`equipo`.`id_equipo`))) desc;

