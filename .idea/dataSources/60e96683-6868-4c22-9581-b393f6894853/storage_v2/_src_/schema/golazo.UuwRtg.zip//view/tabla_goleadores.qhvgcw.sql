create view tabla_goleadores as
  select
    `golazo`.`jugador`.`nomb_jugador` AS `nomb_jugador`,
    `golazo`.`equipo`.`nom_equipo`    AS `nom_equipo`,
    count(0)                          AS `goles`
  from ((`golazo`.`goles`
    join `golazo`.`jugador` on ((`golazo`.`goles`.`id_jugadores_fk` = `golazo`.`jugador`.`id_jugador`))) join
    `golazo`.`equipo` on ((`golazo`.`equipo`.`id_equipo` = `golazo`.`goles`.`id_equipos_fk`)))
  group by `golazo`.`jugador`.`nomb_jugador`
  order by count(0) desc;

