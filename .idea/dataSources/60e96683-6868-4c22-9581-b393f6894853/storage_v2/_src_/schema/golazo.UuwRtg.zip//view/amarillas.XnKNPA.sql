create view amarillas as
  select
    `golazo`.`jugador`.`nomb_jugador` AS `nomb_jugador`,
    `golazo`.`equipo`.`nom_equipo`    AS `nom_equipo`,
    count(0)                          AS `amarillas`
  from ((`golazo`.`amonestaciones`
    join `golazo`.`jugador` on ((`golazo`.`amonestaciones`.`id_jugadore_fk` = `golazo`.`jugador`.`id_jugador`))) join
    `golazo`.`equipo` on ((`golazo`.`equipo`.`id_equipo` = `golazo`.`amonestaciones`.`id_equipos_fk`)))
  where (`golazo`.`amonestaciones`.`id_amonestaciones` = 2)
  group by `golazo`.`jugador`.`nomb_jugador`
  order by count(0) desc;

