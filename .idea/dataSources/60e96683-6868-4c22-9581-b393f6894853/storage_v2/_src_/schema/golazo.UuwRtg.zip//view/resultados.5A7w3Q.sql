create view resultados as
  select
    `resultados_1`.`id_partido_jugado` AS `id_partido_jugado`,
    `resultados_1`.`equipo_local`      AS `equipo_local`,
    `resultados_1`.`resultado_local`   AS `goles_local`,
    (case when (`resultados_1`.`resultado_local` > `resultados_1`.`resultado_visita`)
      then 3
     when (`resultados_1`.`resultado_visita` > `resultados_1`.`resultado_local`)
       then 0
     else 1 end)                       AS `puntos_del_local`,
    `resultados_1`.`equipo_visita`     AS `equipo_visita`,
    `resultados_1`.`resultado_visita`  AS `goles_visitante`,
    (case when (`resultados_1`.`resultado_local` < `resultados_1`.`resultado_visita`)
      then 3
     when (`resultados_1`.`resultado_visita` < `resultados_1`.`resultado_local`)
       then 0
     else 1 end)                       AS `puntos_del_visitante`
  from `golazo`.`resultados_1`;

